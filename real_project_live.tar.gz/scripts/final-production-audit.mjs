import { execSync } from "node:child_process";
import fs from "fs";
import path from "node:path";

async function runFinalTerminalAudit() {
  console.log("🎬 [شاشة التفتيش والتحقق الفعلي لستوديو كاين للإنتاج]");
  console.log("==================================================");

  // 1. فحص ملفات قاعدة البيانات وهيكليتها
  console.log("🔍 [1/5] جاري تفتيش هيكلية ملفات الداتابيز والـ Schema...");
  try {
    if (fs.existsSync("lib/db/src/schema/edit_clips.ts") && fs.existsSync("lib/db/src/schema/renders.ts") && fs.existsSync("lib/db/src/schema/subtitles.ts")) {
      console.log("🟢 [PASS]: الجداول والـ Schema الحالية للـ Timeline والترجمة والرندر محقونة ومستقرة بأمان.");
    } else {
      console.log("🔴 [BLOCKER]: بعض ملفات الـ Schema الأساسية مفقودة من المجلد.");
    }
  } catch (err) {
    console.log("🔴 [BLOCKER]: عاجز عن فحص مجلد قاعدة البيانات.");
  }

  // 2. فحص أداة FFmpeg السينمائية بعد التثبيت
  console.log("\n🔍 [2/5] جاري التحقق من محرك الرندر المحلي (FFmpeg Engine)...");
  try {
    const ffCheck = execSync("ffmpeg -version").toString().split("\n")[0];
    console.log(`🟢 [PASS]: محرك FFmpeg مثبت ونشط في سيرفر أمازون بنجاح: [${ffCheck}]`);
  } catch (err) {
    console.log("🔴 [BLOCKER]: أداة FFmpeg مفقودة أو محظورة الوصول في نظام التشغيل.");
  }

  // 3. فحص الـ API Health والملفات المعنية
  console.log("\n🔍 [3/5] جاري تفتيش الربط المعماري للمسارات (API Health & Routes Check)...");
  try {
    const routeFile = fs.readFileSync("artifacts/api-server/src/routes/video.ts", "utf8");
    if (routeFile.includes("executeFullAutoEditPipeline") && routeFile.includes("proxyVideo")) {
      console.log("🟢 [PASS]: ملفات الـ Routes متكاملة وتحتوي على خط الإنتاج التسلسلي الحقيقي الموحد لـ Auto-Edit.");
    } else {
      console.log("🔴 [BLOCKER]: كود الـ Pipeline التسلسلي ناقص أو لم يتم حقنه بشكل كامل.");
    }
  } catch (err) {
    console.log("🔴 [BLOCKER]: عاجز عن الوصول لملفات الـ API المدونة في السيرفر.");
  }

  // 4. فحص الأصول والمجلدات المحلية لضمان منع الـ Timeout بعد الإصلاح
  console.log("\n🔍 [4/5] جاري فحص مسارات حفظ الأصول على القرص (Asset File Integrity)...");
  const audioDir = path.resolve("artifacts/studio/dist/public/assets/audio");
  const rendersDir = path.resolve("artifacts/studio/dist/public/assets/renders");
  
  if (fs.existsSync(audioDir) && fs.existsSync(rendersDir)) {
    console.log("🟢 [PASS]: المجلدات المحلية متهيئة بالكامل لاستيعاب وحفظ ملفات الـ MP4 والصوت حقيقياً.");
  } else {
    console.log("🔴 [BLOCKER]: مجلدات حفظ الأصول مفقودة على القرص، ستسبب تعطل الرندر.");
  }

  // 5. فحص تكامل الـ Tokens والمفاتيح السحابية لـ Deepgram و Replicate
  console.log("\n🔍 [5/5] جاري فحص حقن مفاتيح الـ AI (Credentials Variables Check)...");
  if (process.env.DEEPGRAM_API_KEY && process.env.REPLICATE_API_TOKEN) {
    console.log("🟢 [PASS]: المفاتيح الرسمية لـ Deepgram ومزامنة Replicate محقونة ومحمية في السيرفر الخلفي.");
  } else {
    console.log("🔴 [BLOCKER]: متغيرات البيئة مفقودة أو لم يتم تصديرها للـ Shell الحالي.");
  }

  console.log("\n==================================================");
  console.log("🎬 [انتهى فحص الترمنال التلقائي المستقر بنجاح]");
}

runFinalTerminalAudit();
