import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

async function runLiveAudit() {
  console.log("🔍 [1/4] جاري التحقق من أداة FFmpeg السينمائية في السيرفر...");
  try {
    const ffmpegVersion = execSync("ffmpeg -version").toString().split("\n")[0];
    console.log(`🟢 PASS: أداة FFmpeg منطلقة ومثبتة في سيرفر أمازون بنجاح: [${ffmpegVersion}]`);
  } catch (ffErr) {
    console.log("🔴 BLOCKER: أداة FFmpeg غير مثبتة أو محظورة الوصول في سيرفر الـ Ubuntu المجاني.");
  }

  console.log("\n🔍 [2/4] جاري فحص تكامل مفاتيح الـ API السحابية (Credentials Token Check)...");
  const deepgramKey = process.env.DEEPGRAM_API_KEY;
  const replicateToken = process.env.REPLICATE_API_TOKEN;
  
  if (deepgramKey && replicateToken) {
    console.log("🟢 PASS: المفاتيح الرسمية لـ Deepgram Aura و Replicate Kling محقونة ومحمية في الـ Backend.");
  } else {
    console.log("🔴 BLOCKER: الـ API Keys مفقودة من بيئة التشغيل الحالية للترمنال.");
  }

  console.log("\n🔍 [3/4] جاري تفتيش مسارات وبث الأصول المحلية (Asset File Management)...");
  const renderAssetsDir = path.resolve("artifacts/studio/dist/public/assets/renders");
  const audioAssetsDir = path.resolve("artifacts/studio/dist/public/assets/audio");
  
  if (!fs.existsSync(renderAssetsDir)) { 
    console.log("⚠️ WARNING: مجلد الرندر النهائي المخرج غير موجود على القرص."); 
  } else {
    console.log("🟢 PASS: مجلد الرندر النهائي المخرج مستقر وجاهز.");
  }
  if (!fs.existsSync(audioAssetsDir)) { 
    console.log("⚠️ WARNING: مجلد أصول الصوت لـ Deepgram غير موجود على القرص."); 
  } else {
    console.log("🟢 PASS: مجلد أصول الصوت لـ Deepgram مستقر وجاهز.");
  }

  console.log("\n🔍 [4/4] جاري فحص سلامة الربط المعماري واستجابة الـ HTTP API...");
  try {
    const routeFile = fs.readFileSync("artifacts/api-server/src/routes/video.ts", "utf8");
    if (routeFile.includes("executeBackgroundRender") && routeFile.includes("executeFullAutoEditPipeline")) {
      console.log("🟢 PASS: مسارات الـ Routes متهيئة برمجياً بالكامل لاستقبال طلبات الـ Auto-Edit والتصنيفات الأربع.");
    } else {
      console.log("🔴 BLOCKER: دالة الربط النهائي للـ Pipeline مفقودة أو ناقصة في ملف الراوت.");
    }
  } catch (apiErr) {
    console.log("🔴 BLOCKER: عاجز عن قراءة أو العثور على ملف راوت المعالجة الرئيسي.");
  }
}

runLiveAudit();
