import "dotenv/config";
import app from "./app";
import { logger } from "./lib/logger";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// هنا تم الإصلاح الجذري للمسار الشامل المتوافق مع الإصدار الحديث لـ path-to-regexp v8 لمنع انهيار تشغيل السيرفر
app.get("/*splat", (req, res, next) => {
  if (req.path.startsWith("/api")) {
    return next();
  }

  // فرض قراءة المجلد الصحيح للملفات الساكنة المحقونة في الـ app
  const frontendDistPath = process.env.NODE_ENV === "production" 
    ? "/home/ubuntu/Nashash/artifacts/studio/dist/public"
    : "/home/ubuntu/Nashash/artifacts/studio/dist/public";

  return res.sendFile(require('node:path').join(frontendDistPath, "index.html"), (err) => {
    if (err) {
      next();
    }
  });
});

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening smoothly");
});
