import { Router, type IRouter, type Request, type Response } from "express";
import { eq, asc } from "drizzle-orm";
import { db, editClipsTable, shotsTable, scriptsTable } from "@workspace/db";
import { createClient } from "@deepgram/sdk";
import fs from "node:fs";
import path from "node:path";
import { Readable } from "node:stream";
import {
  ListProjectClipsParams,
  ListProjectClipsResponse,
  CreateClipBody,
  CreateClipResponse,
  UpdateClipParams,
  UpdateClipBody,
  UpdateClipResponse,
  DeleteClipParams,
} from "@workspace/api-zod";

const router: IRouter = Router();
const EN_SUBTITLE_SEPARATOR = "---ENGLISH_SUBTITLES---";

const EXPORTS_DIR = path.join(process.cwd(), "dist", "public", "exports");
if (!fs.existsSync(EXPORTS_DIR)) {
  fs.mkdirSync(EXPORTS_DIR, { recursive: true });
}

router.post("/projects/:id/merge", async (req: Request, res: Response): Promise<void> => {
  const projectId = Number(req.params.id);
  if (!Number.isInteger(projectId) || projectId <= 0) {
    res.status(400).json({ error: "A valid project id is required." });
    return;
  }

  const deepgramApiKey = process.env.DEEPGRAM_API_KEY?.trim();
  if (!deepgramApiKey) {
    res.status(401).json({
      error: "Authentication Failed",
      message: "الرمز البرمجي DEEPGRAM_API_KEY غير موجود في خادم أمازون. يرجى تزويدي بالمفتاح لتفعيله في الطرفية."
    });
    return;
  }

  try {
    req.log.info({ projectId }, "Initiating true Production Voice & Subtitle synthesis workflow...");

    const shots = await db
      .select()
      .from(shotsTable)
      .where(eq(shotsTable.projectId, projectId))
      .orderBy(asc(shotsTable.sceneNumber));

    if (shots.length === 0) {
      res.status(400).json({ error: "No generated scene assets found to merge. Please generate video/audio first." });
      return;
    }

    const [latestScript] = await db
      .select()
      .from(scriptsTable)
      .where(eq(scriptsTable.projectId, projectId))
      .orderBy(asc(scriptsTable.createdAt));

    let englishSubtitlesArray: string[] = [];
    if (latestScript && latestScript.generatedContent.includes(EN_SUBTITLE_SEPARATOR)) {
      const parts = latestScript.generatedContent.split(EN_SUBTITLE_SEPARATOR);
      if (parts && parts[1]) {
        englishSubtitlesArray = parts[1]
          .split("\n")
          .map(line => line.replace(/^SUBTITLE:\s*/i, "").trim())
          .filter(line => line.length > 0);
      }
    }

    await db.delete(editClipsTable).where(eq(editClipsTable.projectId, projectId));

    const deepgram = createClient(deepgramApiKey);
    let order = 1;
    let currentTimelineTime = 0.0;

    for (let i = 0; i < shots.length; i++) {
      const shot = shots[i];
      const duration = shot.durationSeconds || 5;
      const nextTimelineTime = currentTimelineTime + duration;

      // أ. إدراج مسار الفيديو الأساسي (VIDEO TRACK)
      await db.insert(editClipsTable).values({
        projectId,
        title: shot.description || `لقطة مرئية #${shot.sceneNumber}`,
        durationSeconds: duration,
        notes: shot.cameraMovement || "Cinematic video track",
        clipOrder: order++,
        trackType: "video",
        startTime: currentTimelineTime,
        endTime: nextTimelineTime,
        sourceStart: 0,
        sourceEnd: duration,
        volume: 1.0,
        assetId: `video_asset_${shot.id}`
      });

      // ب. إدراج وتوليد مسار الصوت الحقيقي (VOICE TRACK) عبر Deepgram TTS v3 SDK
      if (shot.dialogue && shot.dialogue.trim().length > 0) {
        const audioFileName = `voice_project_${projectId}_shot_${shot.id}.wav`;
        const audioFilePath = path.join(EXPORTS_DIR, audioFileName);

        req.log.info({ shotId: shot.id }, "Requesting real text-to-speech from Deepgram Aura Engine...");
        
        const response = await deepgram.speak.request(
          { text: shot.dialogue },
          { model: "aura-asteria-en", encoding: "linear16", container: "wav" }
        );

        const responseStream = await response.getStream();
        if (!responseStream) throw new Error(`فشل محرك Deepgram في إرجاع دفق صوتي صالح للقطة #${shot.id}`);
        
        // تجميع الـ Chunks برمجياً من الـ Stream بشكل متوافق تماماً مع حزم Node.js الإنتاجية
        const chunks: Buffer[] = [];
        for await (const chunk of responseStream as any) {
          chunks.push(Buffer.from(chunk));
        }
        const audioBuffer = Buffer.concat(chunks);
        fs.writeFileSync(audioFilePath, audioBuffer);

        await db.insert(editClipsTable).values({
          projectId,
          title: `صوت الحوار الحقيقي: ${shot.dialogue.slice(0, 30)}...`,
          durationSeconds: duration,
          notes: `/exports/${audioFileName}`,
          clipOrder: order++,
          trackType: "voice",
          startTime: currentTimelineTime,
          endTime: nextTimelineTime,
          sourceStart: 0,
          sourceEnd: duration,
          volume: 1.0,
          assetId: `voice_asset_${shot.id}`
        });

        // ج. إدراج مسار الترجمة المتزامن الحقيقي (SUBTITLE TRACK)
        const englishTranslation = englishSubtitlesArray[i] || `[Subtitle text for Shot #${shot.id}]`;
        await db.insert(editClipsTable).values({
          projectId,
          title: englishTranslation,
          durationSeconds: duration,
          notes: `Subtitle associated with shotId: ${shot.id}`,
          clipOrder: order++,
          trackType: "subtitle",
          startTime: currentTimelineTime,
          endTime: nextTimelineTime,
          sourceStart: 0,
          sourceEnd: duration,
          volume: 0.0,
          assetId: `sub_asset_${shot.id}`
        });
      }

      currentTimelineTime = nextTimelineTime;
    }

    const finalClips = await db
      .select()
      .from(editClipsTable)
      .where(eq(editClipsTable.projectId, projectId))
      .orderBy(asc(editClipsTable.clipOrder));

    res.json({
      success: true,
      status: "completed",
      provider: "kayan-production-pipeline",
      message: "تم توليد الصوت حقيقياً من Deepgram وبناء مسارات الترجمة والتايم لاين بالكامل بنجاح.",
      clips: finalClips.map(c => ({ ...c, createdAt: c.createdAt.toISOString() }))
    });

  } catch (error) {
    req.log.error({ err: error }, "Production Merge Pipeline failed");
    res.status(502).json({
      error: "Merge and Speech process failed",
      message: error instanceof Error ? error.message : "حدث خطأ غير متوقع أثناء توليد الأصول الصوتية."
    });
  }
});

router.get("/projects/:id/clips", async (req, res): Promise<void> => {
  const params = ListProjectClipsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid parameters" });
    return;
  }
  const clips = await db
    .select()
    .from(editClipsTable)
    .where(eq(editClipsTable.projectId, params.data.id))
    .orderBy(asc(editClipsTable.clipOrder));
  res.json(
    ListProjectClipsResponse.parse(
      clips.map((c) => ({
        ...c,
        durationSeconds: c.durationSeconds ?? null,
        notes: c.notes ?? null,
        assetId: c.assetId ?? null,
        createdAt: c.createdAt.toISOString(),
      }))
    )
  );
});

router.post("/clips", async (req, res): Promise<void> => {
  const parsed = CreateClipBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation Failed" });
    return;
  }
  const [clip] = await db.insert(editClipsTable).values({
    projectId: parsed.data.projectId,
    title: parsed.data.title,
    durationSeconds: parsed.data.durationSeconds ?? null,
    notes: parsed.data.notes ?? null,
    clipOrder: parsed.data.clipOrder,
  }).returning();

  res.status(201).json(
    CreateClipResponse.parse({
      ...clip,
      durationSeconds: clip.durationSeconds ?? null,
      notes: clip.notes ?? null,
      createdAt: clip.createdAt.toISOString(),
    })
  );
});

router.patch("/clips/:id", async (req, res): Promise<void> => {
  const params = UpdateClipParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid layout" });
    return;
  }
  const parsed = UpdateClipBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid update payload" });
    return;
  }
  const updateData: Record<string, any> = {};
  if (parsed.data.title !== undefined) updateData.title = parsed.data.title;
  if (parsed.data.durationSeconds !== undefined) updateData.durationSeconds = parsed.data.durationSeconds;
  if (parsed.data.notes !== undefined) updateData.notes = parsed.data.notes;
  if (parsed.data.clipOrder !== undefined) updateData.clipOrder = parsed.data.clipOrder;

  const [clip] = await db
    .update(editClipsTable)
    .set(updateData)
    .where(eq(editClipsTable.id, params.data.id))
    .returning();
  if (!clip) {
    res.status(404).json({ error: "Clip not found" });
    return;
  }
  res.json(
    UpdateClipResponse.parse({
      ...clip,
      durationSeconds: clip.durationSeconds ?? null,
      notes: clip.notes ?? null,
      createdAt: clip.createdAt.toISOString(),
    })
  );
});

router.delete("/clips/:id", async (req, res): Promise<void> => {
  const params = DeleteClipParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid clip identification" });
    return;
  }
  const [clip] = await db
    .delete(editClipsTable)
    .where(eq(editClipsTable.id, params.data.id))
    .returning();
  if (!clip) {
    res.status(404).json({ error: "Clip not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
