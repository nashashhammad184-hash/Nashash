import { Router, type IRouter, type Request, type Response } from "express";

const router: IRouter = Router();
const MAX_POLLING_ATTEMPTS = 30;
const POLLING_DELAY_MS = 3000;
const REQUEST_TIMEOUT_MS = 10000;

router.post("/lipsync/process", async (req: Request, res: Response): Promise<void> => {
  const { videoUrl, audioUrl } = req.body || {};

  if (!videoUrl || !audioUrl) {
    res.status(400).json({ error: "Both videoUrl and audioUrl are required inputs for real lip sync." });
    return;
  }

  const token = process.env.REPLICATE_API_TOKEN || "r8_Oqq3bqUWc4sHfHrGyvIeDShqkn1zOsy0KvOEg";
  if (!token) {
    res.status(500).json({ error: "REPLICATE_API_TOKEN is missing from environment variables." });
    return;
  }

  try {
    req.log?.info({ videoUrl }, "Initiating real Replicate Lip Sync pipeline");

    // استدعاء نموذج مزامنة الشفاه الفعلي على Replicate (مثال: synclabs/lipsync أو نماذج wav2lip المستقرة)
    const createResponse = await fetch("https://replicate.com", {
      method: "POST",
      headers: {
        "Authorization": `Token ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        // استخدام معرف الإصدار لنموذج مزامنة ميديا احترافي متوافق
        version: "1a8f946e3cb5b85a36c5df53b1bda8fc4c07a049cc39ff61806085a6669c6cf0", 
        input: {
          face: videoUrl,
          audio: audioUrl
        }
      }),
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS)
    });

    if (!createResponse.ok) {
      const errText = await createResponse.text();
      throw new Error(`Replicate LipSync Prediction Failed (${createResponse.status}): ${errText}`);
    }

    const prediction = await createResponse.json() as { id: string; status: string; urls: { get: string } };
    const jobId = prediction.id;
    let pollUrl = prediction.urls.get;

    req.log?.info({ jobId }, "Replicate Lip Sync job created. Polling for finalized track...");

    let syncedVideoUrl: string | null = null;
    let currentStatus = prediction.status;

    // Polling خلفي مكثف لمعاينة حالة الدمج الصوتي البصري الفعلي
    for (let attempt = 0; attempt < MAX_POLLING_ATTEMPTS; attempt++) {
      await new Promise(resolve => setTimeout(resolve, POLLING_DELAY_MS));

      const pollResponse = await fetch(pollUrl, {
        method: "GET",
        headers: {
          "Authorization": `Token ${token}`,
        },
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS)
      });

      if (!pollResponse.ok) {
        throw new Error(`LipSync Polling Failed on attempt ${attempt}`);
      }

      const statusData = await pollResponse.json() as { status: string; output?: string | string[]; error?: string };
      currentStatus = statusData.status;

      req.log?.info({ jobId, currentStatus, attempt }, "Polling Lip Sync status");

      if (currentStatus === "succeeded") {
        if (Array.isArray(statusData.output)) {
          syncedVideoUrl = statusData.output[0];
        } else if (typeof statusData.output === "string") {
          syncedVideoUrl = statusData.output;
        }
        break;
      }

      if (["failed", "canceled"].includes(currentStatus)) {
        throw new Error(`Lip Sync job ended with failure status: ${currentStatus}. Info: ${statusData.error || "Unknown"}`);
      }
    }

    if (!syncedVideoUrl) {
      throw new Error(`Lip Sync processing timed out. Last captured status: ${currentStatus}`);
    }

    req.log?.info("Lip Sync pipeline completed successfully");

    res.json({
      success: true,
      videoUrl: syncedVideoUrl,
      downloadUrl: `/api/video/download?url=${encodeURIComponent(syncedVideoUrl)}`,
      streamUrl: `/api/video/stream?url=${encodeURIComponent(syncedVideoUrl)}`,
      provider: "replicate-lipsync",
      jobId: jobId
    });

  } catch (error) {
    req.log?.error({ err: error }, "Real Lip Sync process failed");
    res.status(502).json({
      error: "Lip Sync process failed",
      message: error instanceof Error ? error.message : "Unknown Replicate processing error",
    });
  }
});

export default router;
