import { Router, type IRouter, type Request, type Response } from "express";
import { GenerateVideoBody, GenerateVideoResponse } from "@workspace/api-zod";
import { Readable } from "node:stream";

const router: IRouter = Router();

const MAX_POLLING_ATTEMPTS = 30;
const POLLING_DELAY_MS = 3000;
const REQUEST_TIMEOUT_MS = 10000;

router.post("/video/generate", async (req: Request, res: Response): Promise<void> => {
  const parsed = GenerateVideoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const token = process.env.REPLICATE_API_TOKEN || "r8_Oqq3bqUWc4sHfHrGyvIeDShqkn1zOsy0KvOEg";

  if (!token || token.startsWith("YOUR_")) {
    res.status(500).json({ error: "REPLICATE_API_TOKEN is missing from environment variables." });
    return;
  }

  try {
    req.log?.info({ prompt: parsed.data.prompt }, "Starting real Replicate video generation job");

    // 1. إنشاء وظيفة التوليد (Prediction) في Replicate باستخدام النموذج المستهدف
    const createResponse = await fetch("https://replicate.com", {
      method: "POST",
      headers: {
        "Authorization": `Token ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        version: "c452144365b40e53a99e46a78bd3bc957117f763f03bda00f77bcbe867f0868c", 
        input: {
          prompt: parsed.data.prompt,
          world_id: parsed.data.worldId,
          micro_expression: parsed.data.microExpression || "neutral"
        }
      }),
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS)
    });

    if (!createResponse.ok) {
      const errText = await createResponse.text();
      throw new Error(`Replicate Creation Failed (${createResponse.status}): ${errText}`);
    }

    const prediction = await createResponse.json() as { id: string; status: string; urls: { get: string } };
    const jobId = prediction.id;
    let pollUrl = prediction.urls.get;

    req.log?.info({ jobId }, "Replicate job created successfully. Starting server-side polling...");

    let videoUrl: string | null = null;
    let currentStatus = prediction.status;

    // 2. عمل Server-side Polling حتى يكتمل الفيديو فعلياً
    for (let attempt = 0; attempt < MAX_POLLING_ATTEMPTS; attempt++) {
      await new Promise(resolve => setTimeout(resolve, POLLING_DELAY_MS));

      const pollResponse = await fetch(pollUrl, {
        method: "GET",
        headers: {
          "Authorization": `Token ${token}`,
        },
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS)
      });

      if (!pollResponse.ok) {
        throw new Error(`Replicate Polling Failed on attempt ${attempt}`);
      }

      const statusData = await pollResponse.json() as { status: string; output?: string | string[]; error?: string };
      currentStatus = statusData.status;

      req.log?.info({ jobId, currentStatus, attempt }, "Polling Replicate job status");

      if (currentStatus === "succeeded") {
        if (Array.isArray(statusData.output)) {
          videoUrl = statusData.output[0];
        } else if (typeof statusData.output === "string") {
          videoUrl = statusData.output;
        }
        break;
      }

      if (["failed", "canceled"].includes(currentStatus)) {
        throw new Error(`Replicate job finished with terminal failure status: ${currentStatus}. Error: ${statusData.error || "Unknown"}`);
      }
    }

    if (!videoUrl) {
      throw new Error(`Replicate job timed out or did not return a valid video URL. Last status: ${currentStatus}`);
    }

    // 3. إرجاع النتيجة الحقيقية والنهائية المتوافقة مع عقود الـ Zod المحددة في المشروع
    res.json(
      GenerateVideoResponse.parse({
        videoUrl: videoUrl,
        downloadUrl: `/api/video/download?url=${encodeURIComponent(videoUrl)}`,
        streamUrl: `/api/video/stream?url=${encodeURIComponent(videoUrl)}`,
        status: "completed",
        provider: "replicate-engine",
        jobId: jobId
      })
    );

  } catch (error) {
    req.log?.error({ err: error }, "Real Video generation process failed");
    res.status(502).json({
      error: "Video generation failed",
      message: error instanceof Error ? error.message : "Unknown Replicate provider error",
    });
  }
});

async function proxyVideo(req: Request, res: Response, asDownload: boolean) {
  const requestedUrl = typeof req.query.url === "string" ? req.query.url : "";
  if (!requestedUrl.startsWith("http")) {
    res.status(400).json({ error: "A valid HTTPS video URL is required." });
    return;
  }

  try {
    const range = typeof req.headers.range === "string" ? req.headers.range : undefined;
    const upstream = await fetch(requestedUrl, {
      headers: range ? { range } : undefined,
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });

    if (!upstream.ok || !upstream.body) {
      res.status(502).json({ error: "Video source is unavailable." });
      return;
    }

    res.status(upstream.status === 206 ? 206 : 200);
    res.setHeader("Content-Type", upstream.headers.get("content-type") || "video/mp4");
    
    const contentLength = upstream.headers.get("content-length");
    const contentRange = upstream.headers.get("content-range");
    if (contentLength) res.setHeader("Content-Length", contentLength);
    if (contentRange) res.setHeader("Content-Range", contentRange);
    res.setHeader("Accept-Ranges", "bytes");
    
    if (asDownload) {
      res.setHeader("Content-Disposition", 'attachment; filename="kayan-production.mp4"');
    }

    Readable.fromWeb(upstream.body as any).pipe(res);
  } catch (error) {
    if (!res.headersSent) {
      res.status(502).json({ error: "Video source could not be reached." });
    }
  }
}

router.get("/video/stream", async (req, res) => {
  await proxyVideo(req, res, false);
});

router.get("/video/download", async (req, res) => {
  await proxyVideo(req, res, true);
});

export default router;
