import { useEffect, useState } from "react";
import {
  Project, useListProjectTasks, useCreateTask, useUpdateTask, useDeleteTask, useListProjectActors,
  getListProjectTasksQueryKey, getListProjectActorsQueryKey, useGetProductionPrompt, getGetProductionPromptQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Plus, CheckCircle2, Circle, Trash2, Calendar, User } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { VideoPlayerPanel } from "./video-player-panel";

export default function ProductionTab({ project }: { project: Project }) {
  const queryClient = useQueryClient();
  const [title, setTitle] = useState("");
  const [assignedActorId, setAssignedActorId] = useState("unassigned");
  const [microExpression, setMicroExpression] = useState("");
  const [scenePrompt, setScenePrompt] = useState("");

  const { data: tasks, isLoading } = useListProjectTasks(project.id, {
    query: { enabled: !!project.id, queryKey: getListProjectTasksQueryKey(project.id) }
  });

  const { data: projectActors } = useListProjectActors(project.id, {
    query: { enabled: !!project.id, queryKey: getListProjectActorsQueryKey(project.id) }
  });

  const { data: productionPrompt } = useGetProductionPrompt(project.id, {
    query: { enabled: !!project.id, queryKey: getGetProductionPromptQueryKey(project.id), refetchOnMount: true }
  });

  useEffect(() => {
    if (productionPrompt?.prompt) setScenePrompt(productionPrompt.prompt);
  }, [productionPrompt?.prompt]);

  const createTask = useCreateTask();
  const updateTask = useUpdateTask();
  const deleteTask = useDeleteTask();

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    createTask.mutate({
      data: {
        projectId: project.id,
        title,
        status: "pending",
        assignedActorId: assignedActorId !== "unassigned" ? parseInt(assignedActorId, 10) : undefined
      }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListProjectTasksQueryKey(project.id) });
        setTitle("");
        setAssignedActorId("unassigned");
        toast.success("تمت إضافة المهمة");
      }
    });
  };

  const toggleStatus = (taskId: number, currentStatus: string) => {
    const newStatus = currentStatus === "completed" ? "pending" : "completed";
    updateTask.mutate({ id: taskId, data: { status: newStatus } }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListProjectTasksQueryKey(project.id) })
    });
  };

  const handleDelete = (id: number) => {
    deleteTask.mutate({ id }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListProjectTasksQueryKey(project.id) })
    });
  };

  if (isLoading) return <div className="flex justify-center p-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;

  const getActorName = (id: number) =>
    projectActors?.find(pa => pa.actorId === id)?.actor?.name?.split("(")[0]?.trim() || "غير معروف";

  const completedCount = tasks?.filter(t => t.status === "completed").length || 0;
  const totalCount = tasks?.length || 0;
  const progress = totalCount === 0 ? 0 : Math.round((completedCount / totalCount) * 100);

  const microExpressions = [
    { value: "غضب_مكتوم", label: "غضب مكتوم" },
    { value: "نظرة_حب_دافئة", label: "نظرة حب دافئة" },
    { value: "صدمة", label: "صدمة" },
    { value: "شك", label: "شك" },
    { value: "ابتسامة_حذرة", label: "ابتسامة حذرة" },
  ];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 rounded-xl bg-card/20 border border-white/5">
          <div className="shrink-0">
            <p className="text-sm font-bold text-white/80">نوع التعبير الحركي</p>
          </div>
          <Select value={microExpression} onValueChange={setMicroExpression}>
            <SelectTrigger className="flex-1 h-11 bg-background/50 border-white/10"><SelectValue placeholder="اختر التعبير الوجهي..." /></SelectTrigger>
            <SelectContent>
              {microExpressions.map(e => <SelectItem key={e.value} value={e.value}>{e.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="rounded-xl border border-white/8 bg-card/20 p-4 space-y-2">
          <label className="text-sm font-semibold text-white/80">وصف المشهد المراد توليده ورندرته</label>
          <Input value={scenePrompt} onChange={(e) => setScenePrompt(e.target.value)} className="h-11 bg-background/50 border-white/10" />
        </div>

        <VideoPlayerPanel
          microExpression={microExpressions.find(e => e.value === microExpression)?.label ?? "neutral"}
          project={project}
          prompt={scenePrompt}
        />
      </div>

      <div className="bg-card/20 p-6 rounded-xl border border-white/5 space-y-4">
        <div className="flex justify-between items-end">
          <div><h2 className="text-2xl font-bold">مهام الإنتاج الفعلي</h2></div>
          <div className="text-3xl font-black text-primary">{progress}%</div>
        </div>
        <div className="w-full h-2 bg-background rounded-full overflow-hidden">
          <div className="h-full bg-primary" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <Card className="bg-card/40 border-white/5 overflow-hidden">
        <CardContent className="p-0">
          <form onSubmit={handleAdd} className="flex flex-col md:flex-row gap-3 p-4 border-b border-white/10 bg-black/20">
            <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="إضافة مهمة جديدة..." className="flex-1 bg-background/50 border-white/10 h-12" />
            <Select value={assignedActorId} onValueChange={setAssignedActorId}>
              <SelectTrigger className="w-full md:w-[200px] h-12 bg-background/50 border-white/10"><SelectValue placeholder="الممثل المكلف" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="unassigned">غير مكلف بممثل</SelectItem>
                {projectActors?.map(pa => (
                  <SelectItem key={pa.actorId} value={pa.actorId.toString()}>
                    {pa.actor?.name?.split("(")[0]?.trim()} ({pa.roleName})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button type="submit" disabled={createTask.isPending || !title.trim()} className="h-12 px-6">
              <Plus className="w-5 h-5" />
            </Button>
          </form>

          <div className="flex flex-col">
            {tasks?.length === 0 ? (
              <div className="p-12 text-center text-muted-foreground">لا توجد مهام حالياً.</div>
            ) : (
              tasks?.map((task) => (
                <div key={task.id} className="flex items-center justify-between p-4 border-b border-white/5 hover:bg-white/5 transition-colors group">
                  <div className="flex items-center gap-4 flex-1">
                    <button onClick={() => toggleStatus(task.id, task.status)} className="shrink-0">
                      {task.status === "completed" ? <CheckCircle2 className="w-6 h-6 text-primary" /> : <Circle className="w-6 h-6 text-muted-foreground" />}
                    </button>
                    <div className={task.status === "completed" ? "opacity-50 line-through" : ""}>
                      <p className="text-lg font-medium text-white/90">{task.title}</p>
                      {task.assignedActorId && <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1"><User className="w-3 h-3" /> المكلف: {getActorName(task.assignedActorId)}</p>}
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 text-muted-foreground" onClick={() => handleDelete(task.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
