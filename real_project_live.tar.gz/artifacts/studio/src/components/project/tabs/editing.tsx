import { useEffect, useMemo, useState, useRef } from "react";
import {
  EditClip, Project, useListProjectClips, useCreateClip, useDeleteClip, useUpdateClip,
  getListProjectClipsQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Loader2, Plus, Film, Scissors, GripVertical, Trash2, Clock, Shield,
  Sparkles, CheckCircle2, AudioLines, WandSparkles, Music, Radio, AlignLeft, Download
} from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { motion } from "framer-motion";

function KayanWatermark({ corner = "top-right" }: { corner?: "top-right" | "top-left" }) {
  const posClass = corner === "top-right" ? "top-2 right-2" : "top-2 left-2";
  return (
    <div className={`absolute ${posClass} z-10 pointer-events-none select-none`}>
      <div className="flex items-center gap-1 px-2 py-0.5 rounded-sm bg-black/50 backdrop-blur-[2px] border border-white/10">
        <Shield className="w-2 h-2 text-primary/70" />
        <span className="text-[8px] font-mono text-white/40 tracking-wide leading-none uppercase">
          PRODUCED BY KAYAN AI
        </span>
      </div>
    </div>
  );
}

function TimelinePreviewArea({
  totalDuration,
  clips,
  selectedClip,
  project,
}: {
  totalDuration: number;
  clips: any[];
  selectedClip?: any;
  project: Project;
}) {
  const [renderJobId, setRenderJobId] = useState<string | null>(null);
  const [renderStatus, setRenderStatus] = useState<"IDLE" | "QUEUED" | "PROCESSING" | "COMPLETED" | "FAILED">("IDLE");
  const [renderProgress, setRenderProgress] = useState(0);
  const [finalMp4Url, setFinalMp4Url] = useState<string | null>(null);
  const [renderError, setVideoError] = useState<string | null>(null);

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, "0")}`;
  
  const videoTracks = clips.filter(c => c.trackType === "video" || !c.trackType);
  const voiceTracks = clips.filter(c => c.trackType === "voice");
  const musicTracks = clips.filter(c => c.trackType === "music");
  const sfxTracks = clips.filter(c => c.trackType === "sfx");
  const subtitleTracks = clips.filter(c => c.trackType === "subtitle");

  const handleStartFinalRender = async () => {
    if (renderStatus === "QUEUED" || renderStatus === "PROCESSING") return;
    setRenderStatus("QUEUED");
    setRenderProgress(0);
    setFinalMp4Url(null);
    setVideoError(null);

    try {
      const response = await fetch(`/api/projects/${project.id}/render/start`, {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      const data = await response.json();
      if (!response.ok || !data.success) throw new Error(data.error || "فشلت تهيئة عملية الرندرة.");
      setRenderJobId(data.jobId);
      setRenderStatus(data.status);
      toast.info("تمت جدولة مهمة التصدير النهائي على السيرفر (QUEUED)");
    } catch (err: any) {
      setRenderStatus("FAILED");
      setVideoError(err.message);
      toast.error(err.message);
    }
  };

  useEffect(() => {
    if (!renderJobId || renderStatus === "COMPLETED" || renderStatus === "FAILED") return;
    let isMounted = true;
    const checkStatus = async () => {
      try {
        const response = await fetch(`/api/render/status/${renderJobId}`);
        const data = await response.json();
        if (isMounted && data.success) {
          setRenderStatus(data.status);
          setRenderProgress(data.progress ?? 0);
          if (data.status === "COMPLETED") {
            setFinalMp4Url(data.outputUrl);
            setRenderJobId(null);
            toast.success("اكتمل الـ Final Render الحقيقي! ملف الـ MP4 جاهز.");
          } else if (data.status === "FAILED") {
            setVideoError(data.error || "فشلت عملية معالجة أصول الفيلم.");
            setRenderJobId(null);
          }
        }
      } catch (err) {
        if (isMounted) {
          setRenderStatus("FAILED");
          setRenderJobId(null);
        }
      }
    };
    const interval = setInterval(checkStatus, 1500);
    return () => { isMounted = false; clearInterval(interval); };
  }, [renderJobId, renderStatus]);

  return (
    <div className="relative rounded-xl overflow-hidden border border-white/8 bg-black/60 p-4 mb-4">
      <KayanWatermark corner="top-right" />
      <div className="mb-4 flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/5 pb-3 gap-2">
        <div className="inline-flex items-center gap-2 text-xs font-mono text-white/50 uppercase tracking-wider">
          <Film className="w-3.5 h-3.5 text-primary" />
          مخطط المسارات والإنتاج النهائي (Timeline & Final Render)
        </div>
        <div className="flex items-center gap-3">
          <div className="text-sm font-mono text-primary font-bold">إجمالي: {formatTime(totalDuration)}</div>
          <Button
            type="button"
            size="sm"
            onClick={handleStartFinalRender}
            disabled={renderStatus === "QUEUED" || renderStatus === "PROCESSING" || clips.length === 0}
            className="h-8 gap-1.5 bg-red-600 text-white font-bold hover:bg-red-500 shadow-[0_0_15px_rgba(220,38,38,0.25)] text-xs rounded"
          >
            {renderStatus === "QUEUED" || renderStatus === "PROCESSING" ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            Final Render
          </Button>
        </div>
      </div>

      {renderStatus !== "IDLE" && (
        <div className="mb-4 p-3 rounded-lg border bg-black/40 border-white/5 space-y-2">
          <div className="flex justify-between items-center text-[11px] font-mono">
            <span className="text-white/60">حالة الخادم: <strong className="text-primary">{renderStatus}</strong></span>
            <span className="text-primary font-bold">{renderProgress}%</span>
          </div>
          <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-primary transition-all duration-300" style={{ width: `${renderProgress}%` }} />
          </div>
          {renderError && <p className="text-[10px] text-red-500 font-mono">خطأ: {renderError}</p>}
          {finalMp4Url && (
            <div className="pt-2 flex flex-col gap-2">
              <video src={finalMp4Url} controls className="w-full rounded border border-white/10 bg-black max-h-48" preload="auto" />
              <a
                href={`/api/video/download?url=${encodeURIComponent(finalMp4Url)}`}
                download="final-kayan-production.mp4"
                className="inline-flex h-8 items-center justify-center gap-2 rounded bg-primary text-xs font-bold text-white hover:bg-primary/90 font-mono"
              >
                <Download className="w-3.5 h-3.5" /> DOWNLOAD FINAL MP4
              </a>
            </div>
          )}
        </div>
      )}

      <div className="space-y-3 font-mono text-xs opacity-75">
        <div className="grid grid-cols-6 items-center gap-2 bg-white/2 p-2 rounded border border-white/5">
          <span className="col-span-1 text-white/60 flex items-center gap-1"><Film className="w-3 h-3 text-blue-400" /> VIDEO</span>
          <div className="col-span-5 bg-blue-500/10 border border-blue-500/30 rounded p-1 text-[10px] text-blue-300 truncate">{videoTracks.length > 0 ? `${videoTracks.length} أصول مرئية` : "فارغ"}</div>
        </div>
        <div className="grid grid-cols-6 items-center gap-2 bg-white/2 p-2 rounded border border-white/5">
          <span className="col-span-1 text-white/60 flex items-center gap-1"><AudioLines className="w-3 h-3 text-green-400" /> VOICE</span>
          <div className="col-span-5 bg-green-500/10 border border-green-500/30 rounded p-1 text-[10px] text-green-300 truncate">{voiceTracks.length > 0 ? `${voiceTracks.length} حوارات Deepgram` : "فارغ"}</div>
        </div>
        <div className="grid grid-cols-6 items-center gap-2 bg-white/2 p-2 rounded border border-white/5">
          <span className="col-span-1 text-white/60 flex items-center gap-1"><Music className="w-3 h-3 text-purple-400" /> MUSIC</span>
          <div className="col-span-5 bg-purple-500/10 border border-purple-500/30 rounded p-1 text-[10px] text-purple-300 truncate">{musicTracks.length > 0 ? `${musicTracks.length} مسارات موسيقى` : "فارغ"}</div>
        </div>
        <div className="grid grid-cols-6 items-center gap-2 bg-white/2 p-2 rounded border border-white/5">
          <span className="col-span-1 text-white/60 flex items-center gap-1"><Radio className="w-3 h-3 text-amber-400" /> SFX</span>
          <div className="col-span-5 bg-amber-500/10 border border-amber-500/30 rounded p-1 text-[10px] text-amber-300 truncate">{sfxTracks.length > 0 ? `${sfxTracks.length} مؤثرات` : "فارغ"}</div>
        </div>
        <div className="grid grid-cols-6 items-center gap-2 bg-white/2 p-2 rounded border border-white/5">
          <span className="col-span-1 text-white/60 flex items-center gap-1"><AlignLeft className="w-3 h-3 text-cyan-400" /> SUBTITLE</span>
          <div className="col-span-5 bg-cyan-500/10 border border-cyan-500/30 rounded p-1 text-[10px] text-cyan-300 truncate">{subtitleTracks.length > 0 ? `${subtitleTracks.length} نصوص ترجمة` : "فارغ"}</div>
        </div>
      </div>
      {selectedClip && (
        <div className="mt-3 pt-2 border-t border-white/5 grid grid-cols-2 gap-2 text-[10px] text-white/40 font-mono">
          <div>المسار: <span className="text-white/80">{selectedClip.trackType || "video"}</span></div>
          <div>شدة الصوت: <span className="text-primary">{(selectedClip.volume ?? 1.0) * 100}%</span></div>
        </div>
      )}
    </div>
  );
}

export default function EditingTab({ project }: { project: Project }) {
  const queryClient = useQueryClient();
  const [title, setTitle] = useState("");
  const [duration, setDuration] = useState("5");
  const [trackType, setTrackType] = useState("video");
  const [volume, setVolume] = useState("1.0");
  const [selectedClipId, setSelectedClipId] = useState<number | null>(null);

  const { data: clips, isLoading } = useListProjectClips(project.id, {
    query: { enabled: !!project.id, queryKey: getListProjectClipsQueryKey(project.id) }
  });

  const createClip = useCreateClip();
  const deleteClip = useDeleteClip();

  const sortedClips = useMemo(
    () => clips ? [...clips].sort((a, b) => a.clipOrder - b.clipOrder) : [],
    [clips],
  );
  const selectedClip = sortedClips.find(clip => clip.id === selectedClipId);

  useEffect(() => {
    if (!sortedClips.length) {
      setSelectedClipId(null);
      return;
    }
    if (!selectedClipId || !sortedClips.some(clip => clip.id === selectedClipId)) {
      setSelectedClipId(sortedClips[0].id);
    }
  }, [selectedClipId, sortedClips]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    const nextOrder = (clips?.length || 0) + 1;
    const durNum = parseInt(duration, 10) || 5;
    
    createClip.mutate({
      data: {
        projectId: project.id,
        title,
        durationSeconds: durNum,
        clipOrder: nextOrder,
        trackType: trackType,
        startTime: 0,
        endTime: durNum,
        sourceStart: 0,
        sourceEnd: durNum,
        volume: parseFloat(volume) || 1.0,
        assetId: `asset_${Date.now()}`
      }
    }, {
      onSuccess: (newClip) => {
        queryClient.invalidateQueries({ queryKey: getListProjectClipsQueryKey(project.id) });
        setSelectedClipId(newClip.id);
        setTitle("");
        toast.success("تمت إضافة المسار إلى التايم لاين الحقيقي");
      }
    });
  };

  const handleDelete = (id: number) => {
    deleteClip.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListProjectClipsQueryKey(project.id) });
        if (selectedClipId === id) setSelectedClipId(null);
      }
    });
  };

  if (isLoading) {
    return <div className="flex justify-center p-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  const totalDuration = sortedClips.reduce((acc, clip) => acc + (clip.durationSeconds || 0), 0);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-card/20 p-6 rounded-xl border border-white/5">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Scissors className="w-6 h-6 text-primary" />
            غرفة المونتاج (Timeline Production)
          </h2>
          <p className="text-muted-foreground mt-1">إدارة المسارات وتوزيع الحوارات، الموسيقى، والمؤثرات حقيقياً.</p>
        </div>
        <div className="text-center px-4 py-2 bg-black/40 rounded-lg border border-white/5">
          <div className="text-xs text-muted-foreground mb-1">المدة الإجمالية</div>
          <div className="text-xl font-mono font-bold text-primary">{formatTime(totalDuration)}</div>
        </div>
      </div>

      <TimelinePreviewArea
        totalDuration={totalDuration}
        clips={sortedClips}
        selectedClip={selectedClip}
        project={project}
      />

      <Card className="bg-card/40 border-white/5">
        <CardContent className="p-0">
          <form onSubmit={handleAdd} className="flex flex-col gap-3 p-4 border-b border-white/10 bg-black/20">
            <div className="flex flex-col md:flex-row gap-3">
              <Input
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="اسم المقطع أو اسم أصل المسار..."
                className="flex-1 bg-background/50 border-white/10"
                required
              />
              <div className="relative w-full md:w-32">
                <Clock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="number"
                  min="1"
                  value={duration}
                  onChange={e => setDuration(e.target.value)}
                  className="pr-9 bg-background/50 border-white/10"
                  required
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 items-center">
              <div className="w-full sm:flex-1 flex items-center gap-2">
                <label className="text-xs text-muted-foreground shrink-0">نوع المسار:</label>
                <select 
                  value={trackType} 
                  onChange={e => setTrackType(e.target.value)}
                  className="flex h-9 w-full rounded-md border border-input bg-background/50 px-3 py-1 text-sm text-white"
                >
                  <option value="video">🎬 VIDEO (فيديو مرئي)</option>
                  <option value="voice">🗣️ VOICE (حوار صوتي)</option>
                  <option value="music">🎵 MUSIC (موسيقى تصويرية)</option>
                  <option value="sfx">🔊 SFX (مؤثرات محيطية)</option>
                  <option value="subtitle">📝 SUBTITLE (نص ترجمة)</option>
                </select>
              </div>

              <div className="w-full sm:w-44 flex items-center gap-2">
                <label className="text-xs text-muted-foreground shrink-0">شدة الصوت:</label>
                <select
                  value={volume}
                  onChange={e => setVolume(e.target.value)}
                  className="flex h-9 w-full rounded-md border border-input bg-background/50 px-3 py-1 text-sm text-white"
                >
                  <option value="1.0">100% (طبيعي)</option>
                  <option value="0.7">70% (منخفض)</option>
                  <option value="0.5">50% (خلفية)</option>
                  <option value="0.2">20% (خافت)</option>
                  <option value="0.0">0% (كتم)</option>
                </select>
              </div>

              <Button type="submit" disabled={createClip.isPending} className="w-full sm:w-auto shrink-0 gap-2">
                {createClip.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                إضافة للمسار
              </Button>
            </div>
          </form>

          <div className="p-6">
            {sortedClips.length === 0 ? (
              <div className="py-12 flex flex-col items-center text-muted-foreground border-2 border-dashed border-white/10 rounded-xl">
                <Film className="w-12 h-12 mb-4 opacity-20" />
                <p>التايم لاين فارغ حالياً.</p>
              </div>
            ) : (
              <div className="flex overflow-x-auto pb-2 gap-2 snap-x">
                {sortedClips.map((clip) => (
                  <div
                    key={clip.id}
                    onClick={() => setSelectedClipId(clip.id)}
                    className={`shrink-0 snap-center w-48 h-32 bg-background border rounded-lg overflow-hidden flex flex-col group relative cursor-pointer ${
                      selectedClipId === clip.id ? "border-primary ring-1 ring-primary/40" : "border-white/10"
                    }`}
                  >
                    <div className="absolute top-1 left-1 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="h-6 w-6 rounded"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(clip.id);
                        }}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                    <div className="h-4 bg-white/5 w-full flex space-x-1 p-1">
                      {[...Array(6)].map((_, i) => <div key={i} className="flex-1 bg-background rounded-sm" />)}
                    </div>
                    <div className="flex-1 p-3 flex flex-col justify-center items-center text-center">
                      <GripVertical className="w-4 h-4 text-white/20 mb-2" />
                      <span className="font-medium text-white/90 line-clamp-2 text-sm">{clip.title}</span>
                    </div>
                    <div className="h-6 bg-black/60 flex items-center justify-between px-2 text-[10px] font-mono text-muted-foreground border-t border-white/10">
                      <span className="text-primary uppercase">{clip.trackType || "video"}</span>
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {clip.durationSeconds}s</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      <div className="text-center py-3 border-t border-white/5">
        <p className="text-[11px] font-mono text-muted-foreground/40 uppercase tracking-widest flex items-center justify-center gap-2">
          <Shield className="w-3 h-3 text-primary/30" />
          {STUDIO_BRAND}
          <Shield className="w-3 h-3 text-primary/30" />
        </p>
      </div>
    </div>
  );
}
