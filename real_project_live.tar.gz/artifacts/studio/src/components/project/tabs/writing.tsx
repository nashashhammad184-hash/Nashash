import React, { useState, useEffect } from "react";
import { Button } from "../../ui/button";
import { Textarea } from "../../ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../../ui/card";
import { Alert, AlertDescription, AlertTitle } from "../../ui/alert";
import { Sparkles, Loader2, AlertCircle, FileText, Globe, User } from "lucide-react";

interface Script {
  id: number;
  projectId: number;
  worldId: number | null;
  idea: string;
  generatedContent: string;
  createdAt: string;
}

interface ActorAssignment {
  id: number;
  roleName: string;
  actor: {
    name: string;
  };
}

export default function WritingTab() {
  // استخلاص معرف المشروع والبيانات مباشرة من الرابط الحالي لضمان أعلى ثبات واستقلالية برمجية
  const urlParts = window.location.pathname.split("/");
  const projectIdFromUrl = Number(urlParts[urlParts.length - 1]) || Number(urlParts[urlParts.length - 2]) || 1;

  const [idea, setIdea] = useState("");
  const [loading, setLoading] = useState(false);
  const [scripts, setScripts] = useState<Script[]>([]);
  const [projectActors, setProjectActors] = useState<string[]>([]);
  const [selectedScript, setSelectedScript] = useState<Script | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Fetch past scripts and current project actors
  useEffect(() => {
    if (!projectIdFromUrl) return;
    
    // 1. Get scripts
    fetch(`/api/projects/${projectIdFromUrl}/scripts`)
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setScripts(data);
          if (data.length > 0) setSelectedScript(data[0]);
        }
      })
      .catch((err) => console.error("Error loading scripts:", err));

    // 2. Get assigned actors to build dynamic constraint array
    fetch(`/api/projects/${projectIdFromUrl}/actors`)
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          const names = data.map((a: ActorAssignment) => a.actor?.name || a.roleName).filter(Boolean);
          setProjectActors(names);
        }
      })
      .catch((err) => console.error("Error loading project actors:", err));
  }, [projectIdFromUrl]);

  const handleGenerate = async () => {
    if (!projectIdFromUrl || !idea.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/scripts/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectId: projectIdFromUrl,
          worldId: project.worldId,
          idea: idea.trim(),
          actors: projectActors,
          durationMinutes: Number(durationMinutes),
          targetScenes: Number(targetScenes),
          genre: genre
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Generation failed");
      }

      const newScript = await response.json();
      setScripts((prev) => [newScript, ...prev]);
      setSelectedScript(newScript);
      setIdea("");
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred during generation.");
    } finally {
      setLoading(false);
    }
  };

  // معالجة السنتينل الحركي وفصل السطور الإنجليزية بدقة كاملة دون تعديل
  const splitScriptContent = (content: string) => {
    if (!content) return { mainText: "", subtitles: "" };
    const parts = content.split("---ENGLISH_SUBTITLES---");
    return {
      mainText: parts[0]?.trim() || "",
      subtitles: parts[1]?.trim() || "",
    };
  };

  const { mainText, subtitles } = splitScriptContent(selectedScript?.generatedContent || "");

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Generate section */}
      <div className="space-y-6 lg:col-span-1">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-indigo-500" />
              AI Script Generator
            </CardTitle>
            <CardDescription>
              Describe your idea, scene, or setup to generate a fully orchestrated cinematic script.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Textarea
                placeholder="Example: Two partners discussing a heavy secret in a dimly lit car during a rainy night..."
                value={idea}
                onChange={(e) => setIdea(e.target.value)}
                rows={5}
                disabled={loading}
              />
            </div>

            {projectActors.length > 0 && (
              <div className="text-xs text-muted-foreground flex flex-wrap gap-1 items-center bg-muted/50 p-2 rounded-md">
                <User className="h-3 w-3 inline text-indigo-400" />
                <span className="font-semibold mr-1">Cast Constraints:</span>
                {projectActors.join(", ")}
              </div>
            )}

            {error && (
              <Alert variant="destructive" className="py-2 px-3 text-xs">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button
              className="w-full flex items-center justify-center gap-2"
              onClick={handleGenerate}
              disabled={loading || !idea.trim()}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Orchestrating...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  Generate Cinematic Script
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* History log list */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              Script Drafts History ({scripts.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0 max-h-[300px] overflow-y-auto">
            {scripts.length === 0 ? (
              <p className="text-xs text-muted-foreground p-4 text-center">No scripts generated yet.</p>
            ) : (
              <div className="divide-y divide-border">
                {scripts.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setSelectedScript(s)}
                    className={`w-full text-left p-3 text-xs transition-colors hover:bg-muted ${
                      selectedScript?.id === s.id ? "bg-muted font-medium border-l-2 border-indigo-500" : ""
                    }`}
                  >
                    <div className="truncate text-foreground mb-1">{s.idea}</div>
                    <div className="text-[10px] text-muted-foreground">
                      {new Date(s.createdAt).toLocaleString()}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Script Viewing workspace area */}
      <div className="lg:col-span-2 space-y-6">
        <Card className="h-full min-h-[500px] flex flex-col">
          <CardHeader className="border-b bg-muted/20">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-md flex items-center gap-2">
                  <FileText className="h-5 w-5 text-indigo-400" />
                  Cinematic Screenplay Output
                </CardTitle>
                {selectedScript && (
                  <CardDescription className="text-xs mt-1">
                    Generated on {new Date(selectedScript.createdAt).toLocaleString()}
                  </CardDescription>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent className="flex-1 p-6 space-y-6 overflow-y-auto max-h-[650px] font-mono text-sm leading-relaxed">
            {!selectedScript ? (
              <div className="h-full flex flex-col items-center justify-center text-muted-foreground py-20">
                <FileText className="h-12 w-12 stroke- mb-2 text-muted-foreground/50" />
                <p className="text-xs">Provide a script prompt on the left sidebar to generate screenplay content.</p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Main Screenplay Block */}
                <div className="whitespace-pre-wrap bg-background p-4 rounded-md border shadow-sm">
                  {mainText}
                </div>

                {/* Technical English Subtitles Section Block */}
                {subtitles && (
                  <div className="mt-8 pt-6 border-t">
                    <div className="flex items-center gap-2 text-xs font-semibold text-indigo-400 mb-3 uppercase tracking-wider">
                      <Globe className="h-4 w-4" />
                      English Production Subtitles Translation
                    </div>
                    <div className="whitespace-pre-wrap bg-indigo-950/20 text-indigo-200/90 p-4 rounded-md border border-indigo-500/20 text-xs">
                      {subtitles}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
