import { pgTable, serial, integer, text, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { shotsTable } from "./shots";

export const subtitlesTable = pgTable("subtitles", {
  id: serial("id").primaryKey(),
  shotId: integer("shot_id").notNull().references(() => shotsTable.id, { onDelete: "cascade" }),
  text: text("text").notNull(),
  startTime: real("start_time").notNull().default(0.0),
  endTime: real("end_time").notNull().default(0.0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertSubtitleSchema = createInsertSchema(subtitlesTable).omit({ id: true, createdAt: true });
export type InsertSubtitle = z.infer<typeof insertSubtitleSchema>;
export type Subtitle = typeof subtitlesTable.$inferSelect;
